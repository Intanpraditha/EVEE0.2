<?php
echo "Folder config OK";
?>
